# from python.src.postgres_data_capture import postgres_data_capture
# def test_function_pushes_information_to_bucket():

#     postgres_data_capture('egg', 'egg')

#     assert False
